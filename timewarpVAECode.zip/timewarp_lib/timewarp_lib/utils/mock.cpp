#include <torch/extension.h>

#include <iostream>

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
}
